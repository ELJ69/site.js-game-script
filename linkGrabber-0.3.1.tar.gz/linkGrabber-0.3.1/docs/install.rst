Install
=======

How to install linkGrabber:

.. code:: bash

	$ python setup.py install

OR on pypi:

.. code:: bash

	$ pip install linkGrabber