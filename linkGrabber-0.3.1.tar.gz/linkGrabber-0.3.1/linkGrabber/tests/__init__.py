""" Basic unit testing """
from .test_scrape import TestScrape

